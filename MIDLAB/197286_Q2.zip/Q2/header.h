#define MAX 20
struct stable
{
    char *fname;
    char *ptype;
};
struct stable stablep[MAX];
struct stable *look;
