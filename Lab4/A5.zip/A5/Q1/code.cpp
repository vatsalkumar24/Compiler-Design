#include <stdio.h>
int main()
{
    while (a)
    {
        if (a)
        {
            printf("hello");
        }
        printf("hello");
    }
}